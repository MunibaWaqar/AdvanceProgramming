# Resources

This folder contains files required for the file handling tasks.

## [Click Here for Additional Resources](https://docs.google.com/document/d/12FgDNp4Is9YJLF-TsE720RIdpaaNQuD2m2KO0gwt4Zc/edit?usp=sharing) :link:

