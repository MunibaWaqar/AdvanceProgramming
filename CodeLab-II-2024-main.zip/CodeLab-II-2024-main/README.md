# CodeLab-II- Exercises

## Repository Contents

## A1 - Skills Portfolio

### Exercises

You should aim to complete these exercises in order as without a firm understanding of previously introduced techniques you may struggle to complete the latter more advanced exercises. 

To complete the exercises:

* First make sure you have cloned this repository to your local machine
* When happy with your solution commit and push your changes back to Github

### Resources

This folder contains files required for the file handling tasks as well as some useful code snippets.
&nbsp;
&nbsp;
## A2 - Data Driven App

You are required to submit the second Assessment Data driven app here. Also submit your all supporting files, evidence of testing and evidence of design.

## 1-2-1 Tutorials

If you are struggling with any of the concepts introduced in class and would like some additional programming help 1-2-1 tutorials are always available. 
To book a tutorial drop an email to arshiya@bathspa.ae or meet the tutor in Faculty Room.


